import torch
import matplotlib.pyplot as plt
import numpy as np
import RNA 

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

from adabmDCA.functional import one_hot
from adabmDCA.stats import get_freq_single_point, get_freq_two_points
from adabmDCA.fasta import compute_weights,get_tokens

def get_effective_frequencies(msa_enc, msa_enc_r, adjustment_tensor, lambda_, device="cuda", dtype=torch.float32, num_classes=21):

    msa_oh = one_hot(msa_enc, num_classes=num_classes).to(dtype)

    weights_nat = compute_weights(msa_enc, device=device, dtype=dtype)
    M_eff = int(weights_nat.sum())

    msa_oh_r = one_hot(msa_enc_r, num_classes=num_classes).to(dtype)

    msa_tot = torch.cat([msa_oh.to(device), msa_oh_r.to(device)], dim=0)  

    k = (lambda_ * M_eff) / len(msa_enc_r)

    weights_tot = torch.cat([weights_nat.flatten().to(device), k * adjustment_tensor.to(device)], dim=0).unsqueeze(1)

    fi_eff = get_freq_single_point(data=msa_tot, weights=weights_tot, pseudo_count=0)
    fij_eff = get_freq_two_points(data=msa_tot, weights=weights_tot, pseudo_count=0)

    fi_eff = torch.clamp(fi_eff, min=0)
    fij_eff = torch.clamp(fij_eff, min=0)

    return fi_eff, fij_eff


def parse_fasta(filepath):
    with open(filepath, 'r') as file:
        fasta_data = file.read().split('>')[1:]
        fasta_records = []
        for record in fasta_data:
            lines = record.split('\n')
            header = lines[0].strip()
            sequence = ''.join(lines[1:]).strip()
            fasta_records.append((header, sequence))
    return fasta_records

def one_hot_encode(sequence, encoding_dict):
    encoded = np.zeros((len(sequence), len(encoding_dict)), dtype=int)
    for i, char in enumerate(sequence):
        if char in encoding_dict:
            encoded[i, encoding_dict[char]] = 1
    return encoded

def get_predictions(train_fasta_file, new_fasta_file):
    fasta_records = parse_fasta(train_fasta_file)
    encoded_sequences = []
    targets = []
    amino_acids = 'ACDEFGHIKLMNPQRSTVWY-'
    encoding_dict = {aa: i for i, aa in enumerate(amino_acids)}
    for header, sequence in fasta_records:
        encoded_seq = one_hot_encode(sequence, encoding_dict)
        is_functional = 1 if 'functional_true' in header else 0
        encoded_sequences.append(encoded_seq)
        targets.append(is_functional)

    min_length = min(seq.shape[0] for seq in encoded_sequences)
    standardized_sequences = [
        seq[:min_length, :] if seq.shape[0] > min_length 
        else np.pad(seq, ((0, min_length - seq.shape[0]), (0, 0)), mode='constant') 
        for seq in encoded_sequences
    ]

    X = np.array([seq.flatten() for seq in standardized_sequences])
    y = np.array(targets)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    log_reg_classifier = LogisticRegression(random_state=42, max_iter=1000)
    log_reg_classifier.fit(X_train, y_train)

    new_fasta_records = parse_fasta(new_fasta_file)
    new_sequences = [seq for header, seq in new_fasta_records]
    encoded_new_sequences = [one_hot_encode(seq, encoding_dict) for seq in new_sequences]

    standardized_new_sequences = [
        seq[:min_length, :] if seq.shape[0] > min_length
        else np.pad(seq, ((0, min_length - seq.shape[0]), (0, 0)), mode='constant')
        for seq in encoded_new_sequences
    ]

    X_new = np.array([seq.flatten() for seq in standardized_new_sequences])

    predictions = log_reg_classifier.predict(X_new)


    return predictions

def plot_prediction_histogram(predictions,lambda_):

    plt.figure(figsize=(7, 7))

    counts_false = sum(pred == 0 for pred in predictions)
    counts_true = sum(pred == 1 for pred in predictions)

    total = len(predictions)
    percentages_false = (counts_false / total) * 100
    percentages_true = (counts_true / total) * 100

    plt.bar(0, percentages_false, color='blue', alpha=0.5, label=f"Predictions: $\lambda = {lambda_} $")
    plt.bar(1, percentages_true, color='blue', alpha=0.5)

    plt.text(0, percentages_false / 2 + 5, f'{percentages_false:.1f}%', ha='center', va='center', color='black', fontsize=25)
    plt.text(1, percentages_true / 2 + 5, f'{percentages_true:.1f}%', ha='center', va='center', color='black', fontsize=25)

    plt.xticks(ticks=[0, 1], labels=["false", "true"], fontsize=24)
    plt.ylabel("(%)", fontsize=24)
    plt.grid(axis='y', alpha=0)
    plt.ylim(0, 100) 
    plt.yticks(fontsize=20)
    plt.legend(fontsize=22, title_fontsize=24, loc="upper right")

    plt.show()


def compute_thermoscore(dot_bracket_structure, sequences_ART):
    tokens = get_tokens("rna")
    sequences_RNA = ["".join(tokens[i] for i in sequence) for sequence in sequences_ART]
    thermoscores = []
    for sequence in sequences_RNA:
        fc = RNA.fold_compound(sequence)
        thermoscore = -fc.eval_structure(dot_bracket_structure)
        thermoscores.append(thermoscore)

    return thermoscores